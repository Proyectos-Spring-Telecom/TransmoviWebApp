import { Component, ViewChild } from '@angular/core';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { DxDataGridComponent } from 'devextreme-angular';
import CustomStore from 'devextreme/data/custom_store';
import { NgxPermissionsService } from 'ngx-permissions';
import { lastValueFrom } from 'rxjs';
import { MantenimientoVehicularService } from 'src/app/shared/services/mat-vehicular.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-mantenimiento-vehicular',
  templateUrl: './mantenimiento-vehicular.component.html',
  styleUrl: './mantenimiento-vehicular.component.scss',
})
export class MantenimientoVehicularComponent {

  public mensajeAgrupar: string = 'Arrastre un encabezado de columna aquí para agrupar por esa columna';
  public listaManVehicular: any;
  public showFilterRow: boolean;
  public showHeaderFilter: boolean;
  public loading: boolean;
  public loadingMessage: string = 'Cargando...';
  public showExportGrid: boolean;
  public paginaActual: number = 1;
  public totalRegistros: number = 0;
  public pageSize: number = 20;
  public totalPaginas: number = 0;
  @ViewChild(DxDataGridComponent, { static: false }) dataGrid: DxDataGridComponent;
  public autoExpandAllGroups: boolean = true;
  isGrouped: boolean = false;
  public paginaActualData: any[] = [];
  public filtroActivo: string = '';


  constructor(
    private router: Router,
    private manteVeh: MantenimientoVehicularService,
    private permissionsService: NgxPermissionsService,
    private sanitizer: DomSanitizer,
  ) {
    this.showFilterRow = true;
    this.showHeaderFilter = true;
  }

  ngOnInit() {
    this.setupDataSource();
    // this.obtenerlistaManVehicular();
  }

  hasPermission(permission: string): boolean {
    return this.permissionsService.getPermission(permission) !== undefined;
  }

  obtenerlistaManVehicular() {
    this.loading = true;
    this.manteVeh.obtenerManVehiculares().subscribe((response: any[]) => {
      this.loading = false;
      this.listaManVehicular = response;
    });
  }

  agregarManVehicular() {
    this.router.navigateByUrl('/mantenimientos/agregar-mantenimiento-vehicular');
  }

  actualizarManVehicular(idManVehicular: number) {
    this.router.navigateByUrl('/mantenimientos/editar-mantenimiento-vehicular/' + idManVehicular);
  }

  activar(rowData: any) {
    Swal.fire({
      title: '¡Activar!',
      html: `¿Está seguro que requiere activar está instalación?`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Confirmar',
      cancelButtonText: 'Cancelar',
      background: '#002136',
    }).then((result) => {
      if (result.value) {
        this.manteVeh.activarMantenimiento(rowData.id).subscribe(
          (response) => {
            Swal.fire({
              title: '¡Confirmación Realizada!',
              html: `La instalación ha sido activada.`,
              icon: 'success',
              background: '#002136',
              confirmButtonColor: '#3085d6',
              confirmButtonText: 'Confirmar',
            });
            this.setupDataSource();
            this.dataGrid.instance.refresh();
          },
          (error) => {
            Swal.fire({
              title: '¡Ops!',
              html: `${error}`,
              icon: 'error',
              background: '#002136',
              confirmButtonColor: '#3085d6',
              confirmButtonText: 'Confirmar',
            });
          }
        );
      }
    });
  }

  desactivar(rowData: any) {
    Swal.fire({
      title: '¡Desactivar!',
      html: `¿Está seguro que requiere desactivar está instalación?`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Confirmar',
      cancelButtonText: 'Cancelar',
      background: '#002136',
    }).then((result) => {
      if (result.value) {
        this.manteVeh.desactivarMantenimiento(rowData.id).subscribe(
          (response) => {
            Swal.fire({
              title: '¡Confirmación Realizada!',
              html: `La instalación ha sido desactivada.`,
              icon: 'success',
              background: '#002136',
              confirmButtonColor: '#3085d6',
              confirmButtonText: 'Confirmar',
            });
            this.setupDataSource();
            this.dataGrid.instance.refresh();
          },
          (error) => {
            Swal.fire({
              title: '¡Ops!',
              html: `${error}`,
              icon: 'error',
              background: '#002136',
              confirmButtonColor: '#3085d6',
              confirmButtonText: 'Confirmar',
            });
          }
        );
      }
    });
  }


  onPageIndexChanged(e: any) {
    const pageIndex = e.component.pageIndex();
    this.paginaActual = pageIndex + 1;
    e.component.refresh();
  }

  setupDataSource() {
    this.loading = true;

    this.listaManVehicular = new CustomStore({
      key: 'id',
      load: async (loadOptions: any) => {
        const take = Number(loadOptions?.take) || this.pageSize || 10;
        const skip = Number(loadOptions?.skip) || 0;
        const page = Math.floor(skip / take) + 1;

        try {
          const resp: any = await lastValueFrom(
            this.manteVeh.obtenerManVehicularesData(page, take)
          );
          this.loading = false;
          const rows: any[] = Array.isArray(resp?.data) ? resp.data : [];
          const meta = resp?.paginated || {};
          const totalRegistros =
            toNum(meta.total) ??
            toNum(resp?.total) ??
            rows.length;

          const paginaActual =
            toNum(meta.page) ??
            toNum(resp?.page) ??
            page;

          const totalPaginas =
            toNum(meta.lastPage) ??
            toNum(resp?.pages) ??
            Math.max(1, Math.ceil(totalRegistros / take));

          const dataTransformada = rows.map((item: any) => ({
            ...item,
            estatusTexto:
              item?.estatus === 1 ? 'Activo' :
                item?.estatus === 0 ? 'Inactivo' : null
          }));

          this.totalRegistros = totalRegistros;
          this.paginaActual = paginaActual;
          this.totalPaginas = totalPaginas;
          this.paginaActualData = dataTransformada;

          return {
            data: dataTransformada,
            totalCount: totalRegistros
          };
        } catch (err) {
          this.loading = false;
          console.error('Error en la solicitud de datos:', err);
          return { data: [], totalCount: 0 };
        }
      }
    });

    function toNum(v: any): number | null {
      const n = Number(v);
      return Number.isFinite(n) ? n : null;
    }
  }

  onGridOptionChanged(e: any) {
    if (e.fullName !== 'searchPanel.text') return;

    const grid = this.dataGrid?.instance;
    const texto = (e.value ?? '').toString().trim().toLowerCase();
    if (!texto) {
      this.filtroActivo = '';
      grid?.option('dataSource', this.listaManVehicular);
      return;
    }
    this.filtroActivo = texto;
    let columnas: any[] = [];
    try {
      const colsOpt = grid?.option('columns');
      if (Array.isArray(colsOpt) && colsOpt.length) columnas = colsOpt;
    } catch { }
    if (!columnas.length && grid?.getVisibleColumns) {
      columnas = grid.getVisibleColumns();
    }
    const dataFields: string[] = columnas
      .map((c: any) => c?.dataField)
      .filter((df: any) => typeof df === 'string' && df.trim().length > 0);
    const normalizar = (val: any): string => {
      if (val === null || val === undefined) return '';
      if (val instanceof Date) {
        const dd = String(val.getDate()).padStart(2, '0');
        const mm = String(val.getMonth() + 1).padStart(2, '0');
        const yyyy = val.getFullYear();
        return `${dd}/${mm}/${yyyy}`.toLowerCase();
      }
      return String(val).toLowerCase();
    };
    const dataFiltrada = (this.paginaActualData || []).filter((row: any) => {
      const hitEnColumnas = dataFields.some((df) => normalizar(row?.[df]).includes(texto));
      const extras = [
        normalizar(row?.id),
        normalizar(row?.estatusTexto)
      ];

      return hitEnColumnas || extras.some((s) => s.includes(texto));
    });
    grid?.option('dataSource', dataFiltrada);
  }

  toggleExpandGroups() {
    const groupedColumns = this.dataGrid.instance
      .getVisibleColumns()
      .filter((col) => col.groupIndex >= 0);
    if (groupedColumns.length === 0) {
      Swal.fire({
        title: '¡Ops!',
        text: 'Debes arrastar un encabezado de una columna para expandir o contraer grupos.',
        icon: 'warning',
        showCancelButton: false,
        confirmButtonColor: '#3085d6',
        confirmButtonText: 'Entendido',
        allowOutsideClick: false,
      });
    } else {
      this.autoExpandAllGroups = !this.autoExpandAllGroups;
      this.dataGrid.instance.refresh();
    }
  }

  limpiarCampos() {
    this.dataGrid.instance.clearGrouping();
    this.dataGrid.instance.pageIndex(0);
    this.dataGrid.instance.refresh();
    this.isGrouped = false;
  }
 pdfPopupVisible = false;
  pdfTitle = 'Documento';
  pdfPopupWidth = 500;

  pdfUrlSafe: SafeResourceUrl | null = null;
  pdfRawUrl: string | null = null;
  pdfLoading = false;
  pdfLoaded = false;
  esImagen = false;
  pdfError = false;
  pdfErrorMsg = '';


async previsualizar(url?: string, titulo?: string, _row?: any) {
  this.pdfTitle = titulo || 'Documento';
  this.pdfRawUrl = (url || '').trim() || null;

  this.pdfUrlSafe = null;
  this.pdfLoading = true;
  this.pdfLoaded = false;
  this.pdfError = false;
  this.pdfErrorMsg = '';
  this.pdfPopupVisible = true;
  this.pdfPopupWidth = Math.min(Math.floor(window.innerWidth * 0.95), 900);

  if (!this.pdfRawUrl) {
    this.pdfError = true;
    this.pdfLoading = false;
    this.pdfErrorMsg = 'Este registro no tiene archivo asignado.';
    return;
  }

  try {
    const head = await fetch(this.pdfRawUrl, { method: 'HEAD', mode: 'cors' });

    if (!head.ok) {
      this.pdfError = true;
      this.pdfErrorMsg = `No se pudo acceder al archivo (HTTP ${head.status}).`;
      this.pdfLoading = false;
      return;
    }

    const ct = (head.headers.get('content-type') || '').toLowerCase();

    // ⬅️ Detecta IMAGEN
    if (ct.includes('image')) {
      this.mostrarImagen(this.pdfRawUrl);
      return;
    }

    // ⬅️ Detecta PDF
    if (ct.includes('pdf')) {
      const viewerParams = '#toolbar=0&navpanes=0';
      const finalUrl = this.pdfRawUrl.includes('#') ? this.pdfRawUrl : this.pdfRawUrl + viewerParams;

      this.pdfUrlSafe = this.sanitizer.bypassSecurityTrustResourceUrl(finalUrl);
      this.pdfLoading = false;

      return;
    }

    // Otro tipo
    this.pdfError = true;
    this.pdfErrorMsg = 'El archivo no es PDF ni imagen.';
    this.pdfLoading = false;

  } catch (e) {
    this.pdfError = true;
    this.pdfErrorMsg = 'No se pudo cargar el archivo (CORS).';
    this.pdfLoading = false;
  }
}


mostrarImagen(url: string) {
  this.pdfLoading = false;
  this.pdfLoaded = true;

  this.pdfUrlSafe = this.sanitizer.bypassSecurityTrustResourceUrl(url);

  // Marcamos que estamos mostrando imagen
  this.esImagen = true;
}

  onPdfLoaded() {
    this.pdfLoaded = true;
    this.pdfLoading = false;
  }

  abrirEnNuevaPestana() {
    if (this.pdfRawUrl) {
      window.open(this.pdfRawUrl, '_blank');
    }
  }

  async descargarPdfForzada() {
    if (!this.pdfRawUrl) return;
    try {
      const resp = await fetch(this.pdfRawUrl, { mode: 'cors' });
      if (!resp.ok) throw new Error('HTTP ' + resp.status);
      const blob = await resp.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      const base = (this.pdfTitle || 'documento')
        .toLowerCase().replace(/\s+/g, '_').replace(/[^\w\-]+/g, '');
      a.href = url;
      a.download = base.endsWith('.pdf') ? base : base + '.pdf';
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    } catch {
      try {
        const u = new URL(this.pdfRawUrl!);
        u.searchParams.set(
          'response-content-disposition',
          `attachment; filename="${(this.pdfTitle || 'documento').replace(/\s+/g, '_')}.pdf"`
        );
        window.open(u.toString(), '_self');
      } catch {
        window.open(this.pdfRawUrl!, '_blank');
      }
    }
  }
}
